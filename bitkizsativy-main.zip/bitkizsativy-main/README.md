# bitkizsativy
bitki z tej spierdolonej sativy od jakuba siusa i innych pedalow
fineeasz bitki jeakies przerobione budrzetowo
